function changeText1(){
	document.getElementById('noticias').innerHTML = 'Próximamente detallaremos la fecha y hora de la misma. Se realizará en el colegio con padres y acampantes.';
}
	
function changeText2(){
	document.getElementById('noticias').innerHTML = 'Próximamente les dejaremos el link para descargar la autorización para los acampantes del GASJ 77. Esta documentación deberá ser firmada por los padres y presentada antes del viaje.';
}
	
function changeText3(){
	document.getElementById('noticias').innerHTML = 'Próximamente les dejaremos el link para descargar la ficha médica para los acampantes del GASJ 77. Esta documentación deberá ser firmada por los padres y presentada antes del viaje.';	
}
	
function changeText4(){
	document.getElementById('noticias').innerHTML = 'Más información próximamente.';
}
	
function changeText5(){
	document.getElementById('noticias').innerHTML = 'Ya se encuentra actualizado el cronograma para el campamento GASJ 77 - Enero 2021. Pueden encontrarlo en el siguiente link: <a href="http://gasj.com.ar/cronograma.html" id="hipervinculo"><strong>Cronograma GASJ 77</strong>.';
}